
ggplot(Data, aes(x = Année, y = Croissance, color = Groupe, group = Groupe)):

#Cette ligne initialise le graphique ggplot en spécifiant le dataframe Data 
#et les variables esthétiques (aes) utilisées pour le tracé. 
#"Année" est sur l'axe x, "Croissance" est sur l'axe y, et 
#"Groupe" est utilisé pour la couleur des lignes et des points. 
#La spécification group = Groupe est utilisée pour s'assurer que les lignes 
#sont tracées correctement pour chaque groupe.

geom_line(size = 0.9, show.legend = FALSE): 

#Cette ligne ajoute les lignes reliant les points. 
#size = 0.9 spécifie l'épaisseur des lignes, et 
#show.legend = FALSE indique de ne pas afficher cette couche dans la légende.
    
geom_point(size = 2.5): 
  
#Cette ligne ajoute des points correspondant à chaque observation. 
#size = 2.5 spécifie la taille des points.
    
theme_minimal(): 

#Cette ligne applique un thème minimal au graphique, 
#ce qui affecte l'apparence générale du graphique, 
#comme les couleurs de fond et les lignes de grille.

labs(x = "", y = "", color = ""): 
  
#Cette ligne supprime les étiquettes d'axe x, d'axe y et
#de couleur (légende) en les remplaçant par des chaînes de caractères vides.

scale_x_continuous(breaks = seq(1960, 2020, by = 10)): 

#Cette ligne spécifie les points de rupture pour l'axe x, 
#en affichant uniquement les années tous les 10 ans, de 1960 à 2020.
    
scale_color_manual(values = c("#0077be", "#A9A9A9", "#DCDCDC")):

#Cette ligne spécifie manuellement les couleurs à utiliser pour les différents groupes. 
#Dans cet exemple, "#0077be" est bleu, "#A9A9A9" est gris, et "#DCDCDC" est une nuance de gris.
    
guides(color = guide_legend()): 

#Cette ligne spécifie que la légende pour la couleur doit être affichée.
    
theme(legend.position = "top", legend.justification = "left", 
      plot.title = element_text(color = "#0077be", face = "italic", 
                                hjust = 0), 
      plot.caption = element_text(color = "black", hjust = 0, face = "italic")): 

#Cette ligne ajuste différents aspects du thème du graphique. 
#legend.position = "top" positionne la légende en haut du graphique, 
#legend.justification = "left" justifie la légende à gauche, 
#plot.title ajuste le titre du graphique avec une couleur bleue et une police italique, et 
#plot.caption ajuste la légende du graphique avec une couleur noire et une police italique.